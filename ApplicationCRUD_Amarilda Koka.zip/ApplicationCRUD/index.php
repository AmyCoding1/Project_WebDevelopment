<!-- Trupi i faqes -->
<?php include "header.php"; ?>
   
    <div class="row">
        <img class="image-profile" src="img/photo1.jpg" alt="">
    </div>

<?php include "footer.php"; ?>