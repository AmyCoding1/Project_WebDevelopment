<?php 

include "header.php";

$sql = "INSERT INTO `listemployee` (Name, Email, Salary, first_day_of_work, role, Status) 
                    VALUES(:name, :email, :salary, :first_day_of_work, :role, :status)";
                    
$stmt = $conn->prepare($sql);

$stmt ->bindParam(':name', $_POST['name']);
$stmt ->bindParam(':email', $_POST['email']);
$stmt ->bindParam(':salary', $_POST['salary']);
$stmt ->bindParam(':first_day_of_work', $_POST['first_day_of_work']);
$stmt ->bindParam(':role', $_POST['role']);
$stmt ->bindParam(':status', $_POST['status']);

$result = $stmt->execute(); 

if($result){
    header("Location: http://localhost/CRUD_Application/employee.php");
    exit();
}else{
    echo $result;
}

include "footer.php";
?>


